// tailwind.config.js
/** @type {import('tailwindcss').Config} */
export default {
  darkMode: 'class',
  content: ["./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      animation: {
        'dynamic-pastel-pulse': 'dynamic-pastel-pulse-kf 12s ease-in-out infinite',
      },
      keyframes: {
        'dynamic-pastel-pulse-kf': {
          '0%, 100%': {
            backgroundPosition: '0% 50%',
            backgroundSize: '300% 300%',
          },
          '25%': {
            backgroundPosition: '100% 50%',
            backgroundSize: '400% 400%',
          },
          '50%': {
            backgroundPosition: '50% 0%',
            backgroundSize: '300% 300%',
          },
          '75%': {
            backgroundPosition: '50% 100%',
            backgroundSize: '400% 400%',
          },
        },
      },
    },
  },
  plugins: [],
}