
import React, { useEffect, useState, useCallback } from 'react';
import { onAuthStateChanged, signOut, User as FirebaseUser } from 'firebase/auth';
import { auth } from './firebase/config';
import TodoForm from './components/TodoForm';
import TodoList from './components/TodoList';
import useTodoStore from './store/todoStore';
import Login from './components/Login';
import AnimatedBackground from './components/AnimatedBackground';
import { SunIcon, MoonIcon } from '@heroicons/react/24/outline';

const App = () => {
  const [currentUser, setCurrentUser] = useState<FirebaseUser | null>(null);
  const [isLoadingAuth, setIsLoadingAuth] = useState(true);

  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    if (typeof window === 'undefined') {
      return false;
    }
    const storedPreference = localStorage.getItem('theme');
    // Jeśli jest zapisana preferencja, użyj jej. W przeciwnym razie domyślnie jasny.
    return storedPreference === 'dark';
  });

  const fetchTodos = useTodoStore(state => state.fetchTodos);
  const clearTodos = useTodoStore(state => state.clearTodos);

  // Efekt do aktualizacji klasy 'dark' na <html> na podstawie stanu isDarkMode.
  // Zapis do localStorage odbywa się teraz tylko w toggleDarkMode.
  useEffect(() => {
    const root = document.documentElement;
    if (isDarkMode) {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [isDarkMode]);

  // useEffect nasłuchujący na zmiany preferencji systemowych ZOSTAŁ USUNIĘTY.

  // Obsługa autentykacji Firebase (bez zmian)
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (firebaseUser) => {
      setCurrentUser(firebaseUser);
      if (firebaseUser) {
        fetchTodos(firebaseUser.uid);
      } else {
        clearTodos();
      }
      setIsLoadingAuth(false);
    });
    return () => unsubscribe();
  }, [fetchTodos, clearTodos]);

  // Funkcja do ręcznego przełączania trybu przez użytkownika
  const toggleDarkMode = useCallback(() => {
    setIsDarkMode(prevMode => {
      const newMode = !prevMode;
      // Kiedy użytkownik ręcznie przełącza, ZAPISUJEMY jego wybór do localStorage.
      localStorage.setItem('theme', newMode ? 'dark' : 'light');
      console.log("[App - toggleDarkMode] Użytkownik przełączył na:", newMode ? "dark" : "light", ". Zapisano do localStorage.");
      return newMode;
    });
  }, []); // Pusta tablica zależności, bo setIsDarkMode z funkcją zwrotną nie potrzebuje prevMode z closure

  if (isLoadingAuth) {
    return (
      <AnimatedBackground>
        <div className="flex items-center justify-center h-full">
          <p className={`text-xl ${isDarkMode ? 'text-slate-400' : 'text-slate-500'} animate-pulse`}>
            Ładowanie...
          </p>
        </div>
      </AnimatedBackground>
    );
  }

  if (!currentUser) {
    return (
      <AnimatedBackground> {/* Zakładam, że AnimatedBackground jest uniwersalny */}
        {/* Przekazujemy isDarkMode i toggleDarkMode do Login, aby tam też był przycisk */}
        <Login isDarkMode={isDarkMode} toggleDarkMode={toggleDarkMode} />
      </AnimatedBackground>
    );
  }

  return (
    <AnimatedBackground> {/* Zakładam, że AnimatedBackground jest uniwersalny */}
      <div
        className="
          w-full max-w-lg 
          p-6 sm:p-8 
          bg-white/70 backdrop-blur-xl 
          rounded-2xl shadow-2xl 
          border border-white/50
          dark:bg-slate-800/70 dark:backdrop-blur-xl dark:border dark:border-slate-700/50
          transition-colors duration-300
        "
      >
        <header className="flex justify-between items-center mb-6 sm:mb-8">
          <h1 className="text-3xl sm:text-4xl font-bold tracking-tight text-slate-800 dark:text-slate-100">
            📝 Twoje zadania
          </h1>
          <div className="flex items-center gap-3 sm:gap-4">
            <button
              onClick={toggleDarkMode}
              className="p-2 rounded-full text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:focus:ring-sky-500"
              aria-label={isDarkMode ? "Przełącz na tryb jasny" : "Przełącz na tryb ciemny"}
            >
              {isDarkMode ? <SunIcon className="h-6 w-6" /> : <MoonIcon className="h-6 w-6" />}
            </button>
            <button
              onClick={() => signOut(auth)}
              className="px-4 py-2 rounded-lg shadow-md font-semibold transition-all duration-150 ease-in-out bg-rose-500 hover:bg-rose-600 text-white focus:outline-none focus:ring-2 focus:ring-rose-400 focus:ring-offset-2 dark:focus:ring-offset-slate-800/70 focus:ring-offset-white/70 transform hover:scale-105 active:scale-95"
            >
              Wyloguj
            </button>
          </div>
        </header>
        <main>
          <TodoForm user={currentUser} />
          <TodoList />
        </main>
      </div>
    </AnimatedBackground>
  );
};

export default App;