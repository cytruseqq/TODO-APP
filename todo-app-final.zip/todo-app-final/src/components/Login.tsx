// src/components/Login.tsx
import React, { useState } from 'react';
import {
  getAuth,
  signInWithEmailAndPassword,
  GoogleAuthProvider,
  signInWithPopup,
  createUserWithEmailAndPassword,
} from 'firebase/auth';
import { FcGoogle } from 'react-icons/fc';
import { auth } from '../firebase/config';
// Nie importujemy AnimatedBackground, bo Login jest jego dzieckiem
import { SunIcon, MoonIcon } from '@heroicons/react/24/outline'; // Potrzebne dla przycisku

// Definiujemy interfejs propsów dla Login
interface LoginProps {
  isDarkMode: boolean;
  toggleDarkMode: () => void;
}

const Login: React.FC<LoginProps> = ({ isDarkMode, toggleDarkMode }) => {
  const [isLoginMode, setIsLoginMode] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleAuthAction = async (e: React.FormEvent) => {
    e.preventDefault(); setLoading(true); setError(null);
    try {
      if (isLoginMode) await signInWithEmailAndPassword(auth, email, password);
      else await createUserWithEmailAndPassword(auth, email, password);
    } catch (err: any) {
      let friendlyMessage = `${isLoginMode ? 'Logowanie' : 'Rejestracja'} nieudane. Spróbuj ponownie.`;
      switch (err.code) {
          case 'auth/user-not-found': friendlyMessage = 'Nie znaleziono użytkownika.'; break;
          case 'auth/wrong-password': friendlyMessage = 'Nieprawidłowe hasło.'; break;
          case 'auth/email-already-in-use': friendlyMessage = 'Email jest już używany.'; break;
          case 'auth/weak-password': friendlyMessage = 'Hasło zbyt słabe (min. 6 znaków).'; break;
          case 'auth/invalid-email': friendlyMessage = 'Nieprawidłowy email.'; break;
      }
      setError(friendlyMessage);
    } finally { setLoading(false); }
  };

  const handleGoogleLogin = async () => {
    const provider = new GoogleAuthProvider(); setLoading(true); setError(null);
    try { await signInWithPopup(auth, provider); }
    catch (err: any) { setError('Logowanie Google nieudane.'); }
    finally { setLoading(false); }
  };

  const toggleMode = () => {
    setIsLoginMode(!isLoginMode); setError(null); setEmail(''); setPassword('');
  };

  return (
    // Ten div jest teraz dzieckiem AnimatedBackground
    // i jest wycentrowany przez AnimatedBackground dzięki flex i justify-center
    <div
      className={`
        w-full max-w-md 
        p-8 
        bg-white/60 backdrop-blur-xl 
        rounded-2xl shadow-2xl 
        border border-white/40
        dark:bg-slate-800/60 dark:backdrop-blur-xl dark:border-slate-700/50
        transition-colors duration-300
        relative // Umożliwia pozycjonowanie absolutne przycisku zmiany motywu
      `}
    >
      {/* Przycisk do zmiany motywu na stronie logowania */}
      <div className="absolute top-4 right-4 sm:top-5 sm:right-5"> {/* Dopasuj pozycję */}
        <button
          onClick={toggleDarkMode}
          className="p-2 rounded-full text-slate-600 dark:text-slate-300 hover:bg-slate-500/10 dark:hover:bg-slate-300/10 transition-colors focus:outline-none focus:ring-2 focus:ring-purple-500 dark:focus:ring-sky-500"
          aria-label={isDarkMode ? "Przełącz na tryb jasny" : "Przełącz na tryb ciemny"}
        >
          {isDarkMode ? <SunIcon className="h-5 w-5 sm:h-6 sm:w-6" /> : <MoonIcon className="h-5 w-5 sm:h-6 sm:w-6" />}
        </button>
      </div>

      <h2 className="text-4xl sm:text-5xl font-black text-center mb-4 text-transparent bg-clip-text bg-gradient-to-r from-pink-500 via-purple-500 to-indigo-600 drop-shadow-lg">
        Todo App
      </h2>
      <h3 className="text-2xl font-semibold text-center mb-6 text-slate-700 dark:text-slate-200">
        {isLoginMode ? 'Logowanie' : 'Rejestracja'}
      </h3>

      {error && (
        <p className="bg-red-100 border border-red-400 text-red-700 dark:bg-red-900/50 dark:border-red-700 dark:text-red-300 text-center p-3 rounded-lg mb-4 text-sm">
          {error}
        </p>
      )}

      <form onSubmit={handleAuthAction} className="space-y-4">
        {/* Pola input i przyciski formularza ze stylami dark: (bez zmian) */}
        <input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="Email" required className="border border-slate-300 bg-white/90 text-slate-800 placeholder-slate-500 p-3 w-full rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-400 focus:border-pink-400 transition-shadow dark:bg-slate-700/50 dark:border-slate-600 dark:text-slate-100 dark:placeholder-slate-400 dark:focus:ring-sky-500 dark:focus:border-sky-500" />
        <input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="Hasło" required className="border border-slate-300 bg-white/90 text-slate-800 placeholder-slate-500 p-3 w-full rounded-lg focus:outline-none focus:ring-2 focus:ring-pink-400 focus:border-pink-400 transition-shadow dark:bg-slate-700/50 dark:border-slate-600 dark:text-slate-100 dark:placeholder-slate-400 dark:focus:ring-sky-500 dark:focus:border-sky-500" />
        <button type="submit" disabled={loading} className="w-full bg-gradient-to-r from-pink-500 to-purple-500 hover:from-pink-600 hover:to-purple-600 text-white p-3 rounded-lg font-semibold shadow-md transition-all duration-150 ease-in-out transform hover:scale-105 disabled:opacity-70 disabled:cursor-not-allowed dark:from-sky-500 dark:to-blue-600 dark:hover:from-sky-600 dark:hover:to-blue-700">
          {loading ? (isLoginMode ? 'Logowanie...' : 'Rejestracja...') : (isLoginMode ? 'Zaloguj się' : 'Zarejestruj się')}
        </button>
      </form>

      <div className="mt-6 text-center">
        <button onClick={toggleMode} className="text-purple-600 hover:text-purple-700 dark:text-sky-400 dark:hover:text-sky-300 font-medium transition-colors">
          {isLoginMode ? 'Nie masz konta? Zarejestruj się' : 'Masz już konto? Zaloguj się'}
        </button>
      </div>

      <div className="my-6 flex items-center">
        <hr className="flex-grow border-t border-slate-300/70 dark:border-slate-600/50" />
        <span className="px-3 text-slate-500 dark:text-slate-400 text-sm">LUB</span>
        <hr className="flex-grow border-t border-slate-300/70 dark:border-slate-600/50" />
      </div>

      <div className="flex justify-center">
        <button onClick={handleGoogleLogin} disabled={loading} className="flex items-center justify-center gap-3 bg-white hover:bg-slate-100 text-slate-700 font-semibold px-4 py-2.5 rounded-lg shadow-md border border-slate-300 transition-all duration-150 ease-in-out w-full max-w-xs transform hover:scale-105 disabled:opacity-70 disabled:cursor-not-allowed dark:bg-slate-200 dark:hover:bg-slate-300 dark:text-slate-800 dark:border-slate-400">
          <FcGoogle className="text-2xl" />
          <span>{isLoginMode ? 'Zaloguj przez Google' : 'Zarejestruj przez Google'}</span>
        </button>
      </div>
    </div>
  );
};

export default Login;