
import { useForm } from 'react-hook-form'; 
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Timestamp } from 'firebase/firestore';
import dayjs from 'dayjs'; 
import useTodoStore, { type Todo } from '../store/todoStore';

const schema = z.object({
  title: z.string().min(1, "Tytuł jest wymagany"),
  description: z.string().min(1, "Opis jest wymagany"),
  dueDate: z.string() 
  .min(1, "Data jest wymagana")      
    .refine(val => {
      const selectedDate = dayjs(val).startOf('day');
      const today = dayjs().startOf('day');
      return !selectedDate.isBefore(today); 
    }, {
      message: "Termin wykonania nie może być datą z przeszłości."
    }),
});

type FormData = z.infer<typeof schema>;

const TodoForm = ({ user }: { user: { uid: string } }) => {
  const addTodo = useTodoStore(state => state.addTodo);
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
    getValues 
  } = useForm<FormData>({
    resolver: zodResolver(schema),
  });

  const onSubmit = async (data: FormData) => {
    console.log("TodoForm: onSubmit - Dane z formularza:", data);
    console.log("TodoForm: onSubmit - Błędy formularza przed wysłaniem:", errors);

    if (!user || !user.uid) {
      console.error("TodoForm: onSubmit - Brak ID użytkownika!");
      return;
    }

    try {
      const dataToStore = {
        title: data.title,
        description: data.description,
        dueDate: data.dueDate,
        done: false,
        createdAt: Timestamp.now(),
        userId: user.uid,
      };

      await addTodo(dataToStore as Omit<Todo, 'id'>);
      
      console.log("TodoForm: onSubmit - Wywołano addTodo. Formularz przed resetem:", getValues());
      reset(); 
      console.log("TodoForm: onSubmit - Formularz po resecie:", getValues());
      console.log("TodoForm: onSubmit - Błędy formularza po resecie (powinny być puste):", errors);
    } catch (error) {
      console.error("TodoForm: onSubmit - Błąd podczas wywoływania addTodo lub resetowania:", error);
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="bg-white p-6 rounded-lg shadow-lg mb-4"> 
      <h2 className="text-lg font-bold mb-4">Dodaj nowe zadanie</h2>

      <div className="mb-2">
        <input
          {...register('title')}
          placeholder="Tytuł"
          className="border p-2 w-full rounded" 
        />
        {errors.title && <p className="text-red-500 text-xs mt-1">{errors.title.message}</p>}
      </div>

      <div className="mb-2">
        <textarea
          {...register('description')}
          placeholder="Opis"
          className="border p-2 w-full rounded" 
        />
        {errors.description && <p className="text-red-500 text-xs mt-1">{errors.description.message}</p>}
      </div>

      <div className="mb-2">
        <label className="block text-sm font-medium text-gray-700 mb-1">Termin wykonania</label>
        <input
          type="date"
          {...register('dueDate')}
          className="border p-2 w-full rounded" 
        />
        {errors.dueDate && <p className="text-red-500 text-xs mt-1">{errors.dueDate.message}</p>}
      </div>

      <button
        type="submit"
        className="bg-blue-500 text-white p-2 rounded hover:bg-blue-600" 
      >
        Dodaj
      </button>
    </form>
  );
};

export default TodoForm;