// src/components/TodoItem.tsx
import React from 'react';
import { Todo } from '../store/todoStore'; // Upewnij się, że typ Todo jest poprawnie importowany
import useTodoStore from '../store/todoStore';
import dayjs from 'dayjs';

const TodoItem = ({ todo }: { todo: Todo }) => {
  const toggleDone = useTodoStore(state => state.toggleDone);
  const deleteTodo = useTodoStore(state => state.deleteTodo);

  const getDueDateColor = (dueDate?: string) => {
    if (!dueDate) return 'text-gray-400'; // Kolor dla braku terminu

    const today = dayjs().startOf('day');
    const due = dayjs(dueDate).startOf('day');

    if (due.isBefore(today)) return 'text-red-500 font-semibold'; // Po terminie
    if (due.isSame(today)) return 'text-yellow-600 font-semibold'; // Dzisiaj termin
    return 'text-green-600'; // Termin w przyszłości
  };

  const handleToggleDone = () => {
    if (todo.id) {
      toggleDone(todo.id);
    } else {
      console.error("TodoItem: Próba przełączenia statusu zadania bez ID!", todo);
    }
  };

  const handleDeleteTodo = () => {
    if (todo.id) {
      deleteTodo(todo.id);
    } else {
      console.error("TodoItem: Próba usunięcia zadania bez ID!", todo);
    }
  };

  return (
    <div 
      className={`
        bg-white p-4 rounded-xl shadow-lg flex flex-col sm:flex-row justify-between sm:items-center 
        gap-3 sm:gap-4 transition-all duration-300 ease-in-out
        ${todo.done ? 'opacity-70 bg-slate-50' : 'opacity-100'}
      `}
    >
      {/* Sekcja z treścią zadania */}
      <div className="flex-grow">
        <h3 
          className={`
            font-bold text-lg break-words
            ${todo.done ? 'line-through text-gray-400' : 'text-gray-800'}
          `}
        >
          {todo.title}
        </h3>
        {todo.description && (
          <p 
            className={`
              text-sm mt-1 break-words
              ${todo.done ? 'text-gray-400' : 'text-gray-600'}
            `}
          >
            {todo.description}
          </p>
        )}
        {todo.dueDate && (
          <p 
            className={`
              text-xs mt-2 
              ${getDueDateColor(todo.dueDate)}
            `}
          >
            Termin: {dayjs(todo.dueDate).format('DD.MM.YYYY')}
          </p>
        )}
      </div>

      {/* Sekcja z przyciskami akcji */}
      <div className="flex flex-row sm:flex-col gap-2 items-stretch sm:items-end flex-shrink-0 mt-3 sm:mt-0">
        <button
          onClick={handleToggleDone}
          aria-label={todo.done ? "Oznacz jako niezrobione" : "Oznacz jako zrobione"}
          className={`
            px-4 py-2 text-xs sm:text-sm font-semibold rounded-lg shadow-sm transition-all duration-200 ease-in-out
            focus:outline-none focus:ring-2 focus:ring-offset-2
            w-full sm:w-auto
            ${todo.done
              ? 'bg-amber-400 hover:bg-amber-500 text-amber-900 focus:ring-amber-500'
              : 'bg-emerald-500 hover:bg-emerald-600 text-white focus:ring-emerald-600'
            }
          `}
        >
          {todo.done ? 'Niezrobione' : 'Zrobione'}
        </button>
        <button
          onClick={handleDeleteTodo}
          aria-label="Usuń zadanie"
          className="
            px-4 py-2 text-xs sm:text-sm font-semibold rounded-lg shadow-sm bg-rose-500 hover:bg-rose-600 text-white 
            transition-all duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-rose-600 focus:ring-offset-2
            w-full sm:w-auto
          "
        >
          Usuń
        </button>
      </div>
    </div>
  );
};

export default TodoItem;