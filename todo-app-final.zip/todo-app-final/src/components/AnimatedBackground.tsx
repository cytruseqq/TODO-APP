
import React from 'react';

interface AnimatedBackgroundProps {
  children: React.ReactNode;
}

const AnimatedBackground: React.FC<AnimatedBackgroundProps> = ({ children }) => {
  const animationClasses = "animate-dynamic-pastel-pulse";

  const lightGradient = "bg-gradient-to-br from-pink-300 via-purple-400 to-indigo-400";
  const darkGradient = "dark:bg-gradient-to-br dark:from-slate-700 dark:via-indigo-900 dark:to-purple-950";
  
  return (
    <div
      className={`
        min-h-screen w-full 
        flex flex-col items-center justify-center 
        p-4 // Globalny padding dla tła
        transition-colors duration-500 ease-in-out
        ${lightGradient}
        ${darkGradient}
        ${animationClasses}
      `}
    >
      {children}
    </div>
  );
};

export default AnimatedBackground;