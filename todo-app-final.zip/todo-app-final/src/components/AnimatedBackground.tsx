// src/components/AnimatedBackground.tsx
import React from 'react';

interface AnimatedBackgroundProps {
  children: React.ReactNode;
}

const AnimatedBackground: React.FC<AnimatedBackgroundProps> = ({ children }) => {
  // Upewnij się, że animacja 'animate-dynamic-pastel-pulse' jest zdefiniowana w tailwind.config.js
  // i że klatki kluczowe tej animacji (np. 'dynamic-pastel-pulse-kf') ustawiają background-size.
  // Jeśli nie, musisz dodać bg-[length:...] tutaj.
  const animationClasses = "animate-dynamic-pastel-pulse";

  // Uniwersalne gradienty: jeden dla trybu jasnego, jeden dla ciemnego.
  // Używane zarówno dla Login, jak i dla App.
  // OPCJA 3: Bardziej Kontrastowy, ale nadal Pastelowy Róż/Fiolet (Tryb Jasny)
  const lightGradient = "bg-gradient-to-br from-pink-300 via-purple-400 to-indigo-400";
  // Stłumiony Indygo/Niebieski (Tryb Ciemny dla Opcji 3)
  const darkGradient = "dark:bg-gradient-to-br dark:from-slate-700 dark:via-indigo-900 dark:to-purple-950";
  
  return (
    <div
      className={`
        min-h-screen w-full 
        flex flex-col items-center justify-center 
        p-4 // Globalny padding dla tła
        transition-colors duration-500 ease-in-out
        ${lightGradient}
        ${darkGradient}
        ${animationClasses}
      `}
    >
      {children}
    </div>
  );
};

export default AnimatedBackground;