// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getFirestore } from 'firebase/firestore'
import { getAnalytics } from "firebase/analytics";
import { getAuth } from "firebase/auth"
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyCbgfFnlIJFuIqF13anfvcSiddsxjiMg6s",
  authDomain: "apka-projekt.firebaseapp.com",
  projectId: "apka-projekt",
  storageBucket: "apka-projekt.firebasestorage.app",
  messagingSenderId: "724218181191",
  appId: "1:724218181191:web:8f2a710c40f08722882362",
  measurementId: "G-ESX1W1WN6Q"
};


// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);
const auth = getAuth(app)

export { app, auth, analytics }
export const db = getFirestore(app)