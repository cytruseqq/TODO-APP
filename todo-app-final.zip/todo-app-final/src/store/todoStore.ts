// src/store/todoStore.tsx
import { create } from 'zustand'
import {
 collection,
  getDocs,
  addDoc,
  updateDoc,
  deleteDoc,
  doc,
  query,
  where,
  serverTimestamp, 
  Timestamp,      
  FieldValue      
} from 'firebase/firestore'
import { db } from '../firebase/config'

export type Todo = {
  id: string
  title: string
  description: string
  done: boolean
  createdAt: any
  dueDate: string
  userId: string
}

type TodoStore = {
  todos: Todo[]
  fetchTodos: (userId: string) => Promise<void>
  addTodo: (newTodo: Omit<Todo, 'id'>) => Promise<void>
  toggleDone: (id: string) => Promise<void>
  deleteTodo: (id: string) => Promise<void>
   clearTodos: () => void; 
}

const useTodoStore = create<TodoStore>((set, get) => ({
  todos: [],

    clearTodos: () => { 
    console.log("TodoStore: Wywołano clearTodos. Czyszczenie listy zadań.");
    set({ todos: [] });
  },
  fetchTodos: async (userId: string) => {
    try {
      const q = query(collection(db, 'todos'), where('userId', '==', userId))
      const snapshot = await getDocs(q)
      const todos = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data(),
      })) as Todo[]
      set({ todos })
    } catch (error) {
      console.error('Błąd przy pobieraniu zadań:', error)
    }
  },

  addTodo: async (newTodo: Omit<Todo, 'id'>) => { 
  try {
    console.log("[TodoStore - addTodo] Dane wejściowe (newTodo):", JSON.stringify(newTodo, null, 2));

    const objectToSave = {
      ...newTodo, 
      createdAt: serverTimestamp(), 
    };

    // ----- POCZĄTEK KLUCZOWYCH LOGÓW -----
    console.log("------------------------------------------------------");
    console.log("[TodoStore - addTodo] Obiekt PRZYGOTOWANY DO ZAPISU (objectToSave):");
    console.log(JSON.stringify(objectToSave, null, 2));

    console.log("[TodoStore - addTodo] Szczegóły 'createdAt' w objectToSave:");
    console.log("   - Typ wartości: ", typeof objectToSave.createdAt);
    console.log("   - Wartość (jeśli to obiekt, zobacz jego strukturę): ", objectToSave.createdAt);

    console.log("[TodoStore - addTodo] Weryfikacja importu 'serverTimestamp':");
    console.log("   - Typ importowanej funkcji serverTimestamp: ", typeof serverTimestamp);
    if (typeof serverTimestamp === 'function') {
      try {
        const stTest = serverTimestamp();
        console.log("   - Wynik wywołania serverTimestamp(): ", stTest);
        console.log("   - Czy wynik jest instancją FieldValue? ", stTest instanceof FieldValue);
      } catch (e) {
        console.error("   - Błąd przy testowym wywołaniu serverTimestamp():", e)
      }
    }
    console.log("------------------------------------------------------");
    // ----- KONIEC KLUCZOWYCH LOGÓW -----
    const docRef = await addDoc(collection(db, 'todos'), objectToSave);

    console.log("[TodoStore - addTodo] Dokument dodany pomyślnie, ID:", docRef.id);

    set(state => ({
      todos: [...state.todos, { id: docRef.id, ...newTodo }] 
    }));

  } catch (error: any) {
    console.error('[TodoStore - addTodo] BŁĄD PODCZAS addDoc:', error);
    if (error.message) console.error('   - Wiadomość błędu:', error.message);
    if (error.code) console.error('   - Kod błędu Firebase:', error.code);
  }
},
   

  toggleDone: async (id: string) => {
    const todo = get().todos.find(t => t.id === id)
    if (!todo) return

    const previousDone = todo.done

    set(state => ({
      todos: state.todos.map(t =>
        t.id === id ? { ...t, done: !t.done } : t
      )
    }))

    try {
      const todoRef = doc(db, 'todos', id)
      await updateDoc(todoRef, { done: !previousDone })
    } catch (error) {
      console.error('Błąd Firestore, cofanie zmiany:', error)
      set(state => ({
        todos: state.todos.map(t =>
          t.id === id ? { ...t, done: previousDone } : t
        )
      }))
    }
  },

  deleteTodo: async (id: string) => {
    const previousTodos = get().todos
    set(state => ({
      todos: state.todos.filter(todo => todo.id !== id)
    }))

    try {
      await deleteDoc(doc(db, 'todos', id))
    } catch (error) {
      console.error('Błąd Firestore, cofanie usunięcia:', error)
      set({ todos: previousTodos })
    }
  },
}))

export default useTodoStore
