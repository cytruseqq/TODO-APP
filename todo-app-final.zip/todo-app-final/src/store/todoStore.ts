// src/store/todoStore.tsx
import { create } from 'zustand'
import {
 collection,
  getDocs,
  addDoc,
  updateDoc,
  deleteDoc,
  doc,
  query,
  where,
  serverTimestamp, // WAŻNE
  Timestamp,      // Dobrze mieć dla Timestamp.now() i typowania
  FieldValue      // Dobrze mieć dla typowania serverTimestamp
} from 'firebase/firestore'
import { db } from '../firebase/config'

export type Todo = {
  id: string
  title: string
  description?: string
  done: boolean
  createdAt: any
  dueDate?: string
  userId: string
}

// 👇 Dodajemy typ dla całego stanu
type TodoStore = {
  todos: Todo[]
  fetchTodos: (userId: string) => Promise<void>
  addTodo: (newTodo: Omit<Todo, 'id'>) => Promise<void>
  toggleDone: (id: string) => Promise<void>
  deleteTodo: (id: string) => Promise<void>
   clearTodos: () => void; 
}

// 👇 Przekazujemy typ jako generyk do create<TodoStore>
const useTodoStore = create<TodoStore>((set, get) => ({
  todos: [],

    clearTodos: () => { // Implementacja clearTodos
    console.log("TodoStore: Wywołano clearTodos. Czyszczenie listy zadań.");
    set({ todos: [] });
  },
  fetchTodos: async (userId: string) => {
    try {
      const q = query(collection(db, 'todos'), where('userId', '==', userId))
      const snapshot = await getDocs(q)
      const todos = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data(),
      })) as Todo[]
      set({ todos })
    } catch (error) {
      console.error('Błąd przy pobieraniu zadań:', error)
    }
  },

  addTodo: async (newTodo: Omit<Todo, 'id'>) => { // Zakładam, że używasz tego typu
  try {
    // Logujemy dane otrzymane z TodoForm
    console.log("[TodoStore - addTodo] Dane wejściowe (newTodo):", JSON.stringify(newTodo, null, 2));

    // Tworzymy obiekt, który zostanie wysłany do Firestore
    const objectToSave = {
      ...newTodo, // Rozpakowujemy dane z formularza (w tym createdAt: Timestamp.now() z TodoForm)
      createdAt: serverTimestamp(), // Nadpisujemy createdAt serwerowym timestampem
    };

    // ----- POCZĄTEK KLUCZOWYCH LOGÓW -----
    console.log("------------------------------------------------------");
    console.log("[TodoStore - addTodo] Obiekt PRZYGOTOWANY DO ZAPISU (objectToSave):");
    console.log(JSON.stringify(objectToSave, null, 2));

    console.log("[TodoStore - addTodo] Szczegóły 'createdAt' w objectToSave:");
    console.log("   - Typ wartości: ", typeof objectToSave.createdAt);
    console.log("   - Wartość (jeśli to obiekt, zobacz jego strukturę): ", objectToSave.createdAt);

    console.log("[TodoStore - addTodo] Weryfikacja importu 'serverTimestamp':");
    console.log("   - Typ importowanej funkcji serverTimestamp: ", typeof serverTimestamp);
    if (typeof serverTimestamp === 'function') {
      try {
        const stTest = serverTimestamp();
        console.log("   - Wynik wywołania serverTimestamp(): ", stTest);
        console.log("   - Czy wynik jest instancją FieldValue? ", stTest instanceof FieldValue);
      } catch (e) {
        console.error("   - Błąd przy testowym wywołaniu serverTimestamp():", e)
      }
    }
    console.log("------------------------------------------------------");
    // ----- KONIEC KLUCZOWYCH LOGÓW -----
    const docRef = await addDoc(collection(db, 'todos'), objectToSave);

    console.log("[TodoStore - addTodo] Dokument dodany pomyślnie, ID:", docRef.id);

    // Optymistyczna aktualizacja
    set(state => ({
      todos: [...state.todos, { id: docRef.id, ...newTodo }] // Używamy newTodo z oryginalnym createdAt klienta
    }));

  } catch (error: any) {
    console.error('[TodoStore - addTodo] BŁĄD PODCZAS addDoc:', error);
    if (error.message) console.error('   - Wiadomość błędu:', error.message);
    if (error.code) console.error('   - Kod błędu Firebase:', error.code);
    // console.error('   - Pełny obiekt błędu:', error); // Odkomentuj w razie potrzeby
  }
},
   

  toggleDone: async (id: string) => {
    const todo = get().todos.find(t => t.id === id)
    if (!todo) return

    const previousDone = todo.done

    set(state => ({
      todos: state.todos.map(t =>
        t.id === id ? { ...t, done: !t.done } : t
      )
    }))

    try {
      const todoRef = doc(db, 'todos', id)
      await updateDoc(todoRef, { done: !previousDone })
    } catch (error) {
      console.error('Błąd Firestore, cofanie zmiany:', error)
      set(state => ({
        todos: state.todos.map(t =>
          t.id === id ? { ...t, done: previousDone } : t
        )
      }))
    }
  },

  deleteTodo: async (id: string) => {
    const previousTodos = get().todos
    set(state => ({
      todos: state.todos.filter(todo => todo.id !== id)
    }))

    try {
      await deleteDoc(doc(db, 'todos', id))
    } catch (error) {
      console.error('Błąd Firestore, cofanie usunięcia:', error)
      set({ todos: previousTodos })
    }
  },
}))

export default useTodoStore
